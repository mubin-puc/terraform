import pytest
import tftest


@pytest.fixture(scope="module")
def plan_out(fixtures_dir):
  import json
  with open('%s/tfplandpc.json' % fixtures_dir) as fp:
    return tftest.TerraformPlanOutput(json.load(fp))

#To test variables 
def test_variables(plan_out):
  var =  plan_out.variables['project_defaults'] 
  assert var['bucket_logs'] == 'gs://wdwg-dev-aidcom-0-usre-logs-2'
  assert var['email_from_address'] == 'donotreply@verizon.com-22'


#To test resources in block 1  
def test_resources1(plan_out):
  res = plan_out.root_module['child_modules'][0]['resources'][0]
  assert res['address'] == 'module.CF-py.google_cloudfunctions_function.cloud_function'
  assert res['mode'] == 'managed'
  
  
#To test nested resources in block 1
def test_nestedresources1(plan_out):
  nres1 = plan_out.root_module['child_modules'][0]['resources'][0]['values']
  nres1_a =  nres1['event_trigger'][0]
  assert nres1['available_memory_mb'] == 256
  assert nres1_a['event_type'] == 'google.pubsub.topic.publish'
  assert nres1['max_instances'] == 3000
  assert nres1['min_instances'] == 0

#To test resources in block 2 
def test_resources2(plan_out):
  nres2 = plan_out.root_module['child_modules'][1]['resources'][0]
  nres2_a = nres2['values']
  assert nres2['address'] == 'module.add_authorization.google_bigquery_dataset_access.access_role[\"roles/bigquery.dataEditor_krishna.chunduri@verizon.com\"]'
  assert nres2_a['dataset_id'] == 'platform_test_01'

#To test resources in block 3
def test_resources3(plan_out):
  nres3 = plan_out.root_module['child_modules'][2]['resources'][0]
  nres3_a = nres3['values']['secondary_worker_config'][0]
  assert nres3['address'] == 'module.autoscale_policy_dp_lr.google_dataproc_autoscaling_policy.asp'
  assert nres3_a['max_instances'] == 40
  assert nres3_a['min_instances'] == 0


#To test gcs bucket
  
#To test variables 
def test_variables(plan_out):
  var =  plan_out.variables['project_defaults'] 
  assert var['bucket_logs'] == 'gs://wdwg-dev-aidcom-0-usre-logs'
  assert var['email_from_address'] == 'donotreply@verizon.com'
  assert var['gcs_bucket_initaction']=='wdwg-dev-aidcom-0-usmr-initializationaction'


#To test gcs resources in block 1  
def test_resources7(plan_out):
  res = plan_out.root_module['child_modules'][7]['resources'][0]
  assert res['name'] == 'gcs'
  assert res['mode'] == 'managed'
  assert res['address'] == 'module.dataproc-staging-us-east4-873845602764-cckcntw1.google_storage_bucket.gcs'


#To test nested gcs resources in block 1
def test_nestedresources7(plan_out):
  nres1 = plan_out.root_module['child_modules'][7]['resources'][0]['values']
  assert nres1['location'] == 'US-EAST4'
  assert nres1['name'] == "dataproc-staging-us-east4-873845602764-cckcntw1"
  assert nres1['public_access_prevention'] == 'inherited'
  assert nres1['storage_class']== 'STANDARD'

#To test gcs resources in block 1  
def test_resources12(plan_out):
  res = plan_out.root_module['child_modules'][12]['resources'][0]
  assert res['name'] == 'gcs_obj'
  assert res['mode'] == 'managed'
  assert res['address'] == 'module.gcs-object-dpms-update-v1_2_0.google_storage_bucket_object.gcs_obj'


#To test nested gcs resources in block 1
def test_nestedresources12(plan_out):
  nres1 = plan_out.root_module['child_modules'][12]['resources'][0]['values']
  assert nres1['bucket'] == 'wdwg-dev-aidcom-0-usmr-initializationaction'
  assert nres1['storage_class']== 'STANDARD'

#To test gcs resources in block 1  
def test_resources13(plan_out):
  res = plan_out.root_module['child_modules'][13]['resources'][0]
  assert res['name'] == 'gcs_obj'
  assert res['mode'] == 'managed'
  assert res['address'] == 'module.gcs-object-enable_ha_knox_components-v1_1_0.google_storage_bucket_object.gcs_obj'


#To test nested gcs resources in block 1
def test_nestedresources13(plan_out):
  nres1 = plan_out.root_module['child_modules'][13]['resources'][0]['values']
  assert nres1['bucket'] == 'wdwg-dev-aidcom-0-usmr-initializationaction'
  assert nres1['storage_class']== 'STANDARD'
  assert nres1['id'] == 'wdwg-dev-aidcom-0-usmr-initializationaction-initialization-actions/enable_ha_knox_components-v1.1.0.sh'












  










