## Changelog

Use below format when applying changes to modules folders

### YYYY-MM-DD, GCP Service name vMajor.Minor.Patch
### Eg 2022-05-01, Data Proc v1.0.0

### New features

### Documentation changes

### Bug fixes

----

## FAQ

### Data Proc

#### Q: When to increment patch version?
A: Backward compatible bug fixes with out needing to rebuild cluster <br>
   Eg: add labels , no of workers change , auto scale policy changes etc.. <br>
   Refer to https://cloud.google.com/sdk/gcloud/reference/dataproc/clusters/update <br>
### Q: When to increment minor version?
A: Backward compatible changes that require to rebuild cluster <br>
   changes to existing/new init-actions script , startup-script files <br>
   changes to existing/new properties , hard disk type, attributes <br>
### Q: When to use major version?
A: Non backward compatible changes 
   Eg: terraform attributes not compatible with current terraform version <br>
 
