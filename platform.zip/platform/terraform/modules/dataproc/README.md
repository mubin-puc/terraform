## Changelog

### 2022-09-01 Dataproc
### Enhancement
###dp-lr-v1.12.0
- Moved monitoring property to seperate variable now you can disable monitoring using variable properties_dp_monitoring_flag by default this is true

### 2022-08-31 Dataproc
### Enhancement
###dp-lr-v1.12.0
- Added new metadata variable metadata_xmlstartlet_rpm_location to fix oozie ui due to xmlstartlet missing from redhat repo <br>
  Pass variable in dataprod.tf file metadata_xmlstartlet_rpm_location = "gs://wdwg-<dev|test|prod>-aidcom-0-usmr-initializationaction/initialization-actions/lib/xmlstarlet-1.6.1-11.el8.x86_64.rpm"  
- New init script enable_ha_knox_components-v1.2.0.sh should be used as temproary workaroud to fix oozie ui issue

### 2022-08-22 Dataproc Startup script
### Enhancement
- Combining set proxy and startup script by Removing pip in startup script this is to allow monitoring property


### 2022-08-21 Dataproc
### Enhancement
###dp-lr-v1.12.0
- Combined basic & optimzied modules in to one use properties_dp_type = basic or optimized
###dp-lr-v1.11.0
- Combined dp-lr-v1.11.0-basic-setproxy-1.5.0 , dp-lr-v1.11.0-basic-setproxy in to dp-lr-v1.11.0-basic
- Modified dp-lr-v1.11.0-optimized to work for setproxy

### 2022-08-09 Dataproc version init script oozie-rocky-v1.12.0 , oozie-rocky-v2.0.0
### Enhancement

- New init script oozie-rocky-v1.12.0.sh for backward compatibility < 2.0.46-rocky8 images 

Case 40378239
Added logic to the init script to not setup Oozie fluentd configuration when cluster is built with the property dataproc:dataproc.logging.stackdriver.enable=false
Oozie init script fails on image 2.0.46-rocky8 since default MySQL password has changed.
Init script updated to retrieve and use password from /etc/mysql/my.cnf


- New init script oozie-rocky-v2.0.0.sh for forward compatibility >= 2.0.46-rocky8 images or later 

Case 40378239
Added logic to the init script to not setup Oozie fluentd configuration when cluster is built with the property dataproc:dataproc.logging.stackdriver.enable=false
Oozie init script fails on image 2.0.46-rocky8 since default MySQL password has changed.
Init script updated to retrieve and use password from /etc/mysql/my.cnf
Oozie library version changes with version 5.2.1
hadoop-common-3.2.3.jar
woodstox-core-5.3.0.jar
Stax2-api-4.2.1.jar
Dataproc library version changes
hadoop-cloud-storage-3.2.3.jar


### 2022-07-19 Dataproc version dp-lr-v1.11.0
### Enhancement
- Following New modules 
- dp-lr-v1.11.0-basic-setproxy : Basic properties with Set proxy script use
- dp-lr-v1.11.0-basic : Basic properties with startup script
- dp-lr-v1.11.0-optimized : Optimized properties
- dp-lr-v1.11.0-optimized-npi-setproxy : Optimized for NPI
- dp-lr-v1.11.0-basic-setproxy-1.5.0 : To support 1.5 image flink
- enable_ha_knox_components-v1.1.0.sh : Copied file gs://h6zv-dev-npipr-0-usmr-initializationaction/enable_ha_knox_components_v2.sh to gs://wdwg-dev-aidcom-0-usmr-initializationaction/initialization-actions/enable_ha_knox_components-v1.1.0.sh

### 2022-07-08 Dataproc version dp-lr-v1.10.0-basic, dp-lr-v1.10.0-optimized
### Enhancement
Copied from module dp-lr-v1.9.0-gk1v and added few properties
Copied from module dp-lr-v1.9.0 and added few properties

### 2022-06-06 
### Bugfix 
Updated exisiting file since existing dpms-update-v1.2.0.sh having issues
- dpms-update-v1.2.0.sh Google Case #29890416 , Case #29917822 

### 2022-05-31 
### Enhancement
added new file 
- hbase-client-v1.0.0.sh
- storm-v1.0.0.sh Google Case 29691139
Updated file with new version 
- dpms-update-v1.2.0.sh Google Case #29865899
- enable_ha_knox_components-v1.1.0.sh
- cluster-init-v1.1.0.sh  Google Case #29865899


### 2022-05-25 Dataproc version dp-lr-v1.9.0
### Enhancement
added new variable labels_dp_specific to the dp-lr-v1.9.0
added new variable properties_dp_specific to the dp-lr-v1.9.0
Instead of dp-lr-v1.5.0 please use this dp-lr-v1.9.0 so that we can identify its for cluster specific


### 2022-05-23 
### Enhancement
oozie rocky bug fix
- oozie-rocky-v1.10.0.sh Google Case #29872217

### 2022-05-18 
### Enhancement
Added new file pig-v1.0.0.sh from pig-init.sh

### 2022-05-16 Dataproc version 1.9.0
### Enhancement
Added new properties on top of dp v1.5.0
case 29838006 to fix gsutil mv command on DP
- "yarn:yarn.nodemanager.user-home-dir" ="/var/lib/hadoop-yarn"
ZONE is customized 


### 2022-05-16 Dataproc version 1.8.0
### Enhancement this is specific to gupv vsad
Added new properties 
- "hive:tez.counters.max.groups" = 1000
- "hive:tez.counters.max" = 5000
- "tez:tez.counters.max.groups" = 1000
- "tez:tez.counters.max" = 500
- #Case 29763080 5/16/2022
- "hive:mapreduce.job.counters.max" = 20000

### 2022-05-14 
### Enhancement
hcat fix in init script oozie-rocky-v1.7.0.sh taking more than 5 mins 
Changed time out from 5 to 10 mins under all dp-lr modules


### 2022-05-05 Dataproc version 1.7.0

### Bugfix
Dont use oozie-rocky-v1.3.0.sh this doest has hcat fix
copied file oozie-rocky-042122.sh to oozie-rocky-v1.7.0.sh this has hcat issues resolved, 
included oozie-rocky-04262022.sh changes ( workflow max length ) as well

### 2022-05-07 dp-lr-streaming-backward version 1.0.0 , dp-metastore v1.6.0
Not yet ready failing due to hive metastore

### New features
DP Metastore to use Thrift v1.6.0 

### 2022-05-05 Dataproc version 1.5.0

### New features
Following changes were made in this version:
Properties updates:
Removed this property 
- yarn:yarn.nodemanager.resource.cpu-vcores = 30
Updated the following properties:
from 
- hive:hive.server.read.socket.timeout = 6000
to
hive:hive.server.read.socket.timeout = 3600

From 
"spark:spark.io.compression.codec" = "lz4"
to
"spark:spark.io.compression.codec" = "snappy"

### 2022-05-03 Dataproc version 1.4.0

### New features:**
Below changes are made on the - dp-lr-v1.1.0
Adding new properties 
- spark:spark.dynamicAllocation.enabled=true 
- dataproc:dataproc.monitoring.stackdriver.enable=true
- spark:spark.serializer=org.apache.spark.serializer.KryoSerializer
- Updated from spark:spark.io.compression.codec=snappy to spark:spark.io.compression.codec=lz4
Removed these properties:
- spark:spark.dynamicAllocation.enabled = false
- spark:spark.io.compression.snappy.blockSize = 32k
Boot disk type is customized for Master, Primary Worker


### 2022-05-01 Data Proc
### New features
Rename init action files , startup script to use new naming convention <br>
dpms-update.sh -> dpms-update-v1.0.0.sh <br>
dpms-update-1.1.sh -> dpms-update-v1.1.0.sh <br>
cluster-init.sh  -> cluster-init-v1.0.0.sh <br>
enable_ha_knox_components.sh -> enable_ha_knox_components-v1.0.0.sh <br>
oozie-rocky.sh -> oozie-rocky-v1.0.0.sh <br>
oozie-rocky-04262022.sh -> oozie-rocky-v1.3.0.sh <br>
orc.sh -> orc-v1.0.0.sh <br>

### 2022-04-27
### New features
Added labels to dataporoc clusters 

### 2022-04-26
### Bug fixes
added mysql service dependency on oozie service to file oozie-rocky-04262022.sh
Added bdconfig set_property to file oozie-rocky-04262022.sh

### 2022-04-22 Dataproc version 1.2.0
Google recommended config changes secondary workers to use pd-standard 

### 2022-04-21 Dataproc version 1.1.0
### New features
VZ recommended config override properties

### 2022-04-15 Dataproc version 1.0.0
### New features
Google recommended config changes