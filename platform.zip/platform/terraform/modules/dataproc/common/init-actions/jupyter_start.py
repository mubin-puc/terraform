import os
os.system("systemctl start jupyter")
