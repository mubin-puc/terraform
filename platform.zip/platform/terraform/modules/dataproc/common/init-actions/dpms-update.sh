#!bin/bash

# Copyright 2022 Google. This software is provided as-is, without warranty or representation for any use or purpose.
# Your use of it is subject to your agreement with Google.

export PATH=/usr/bin:$PATH
export METADATA_HTTP_PROXY=$(/usr/share/google/get_metadata_value attributes/http-proxy)
export http_proxy="${METADATA_HTTP_PROXY}"
export https_proxy="${METADATA_HTTP_PROXY}"
export HTTP_PROXY="${METADATA_HTTP_PROXY}"
export HTTPS_PROXY="${METADATA_HTTP_PROXY}"
export no_proxy=metadata.google.internal
export NO_PROXY=metadata.google.internal

function update_dpms() {

  sudo gsutil cp gs://metastore-init-actions/metastore-grpc-proxy/hms-proxy-3.1.2-v0.0.30.jar /usr/local/share/google/dataproc/dpms-proxy/3.1.2/hms-proxy-3.1.2.jar

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/dpms-proxy/conf/proxy-config.xml' \
      --name 'proxy.max.message.size.bytes' --value "2147483647" \
      --clobber

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/dpms-proxy/conf/proxy-config.xml' \
      --name 'grpc.max.retries' --value "5" \
      --clobber

  sudo systemctl restart dpms-proxy
}

function main() {
  # Determine the role of this node
  local role
  role=$(/usr/share/google/get_metadata_value attributes/dataproc-role)

  # Only run on the master node of the cluster
  if [[ "${role}" == 'Master' ]]; then
    update_dpms
  fi
}

main