#!/bin/bash
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS-IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Initialization action for installing Apache Storm on a Google Cloud
# Dataproc cluster. This script will install and configure Storm Nimbus to run on the
# master node of a Dataproc cluster. The supervisor will run on a worker.
#
# For more information in init actions and Google Cloud Dataproc see the Cloud
# Dataproc documentation at https://cloud.google.com/dataproc/init-actions
#

set -euxo pipefail

STORM_VERSION="2.2.1"
STORM_HOME="/opt/apache-storm-${STORM_VERSION}"
STORM_USER_HOME="/var/lib/storm"
STORM_USER="storm"
export METADATA_HTTP_PROXY=$(/usr/share/google/get_metadata_value attributes/http-proxy)
export STORM_ENABLE_SSL=$(/usr/share/google/get_metadata_value attributes/storm-enable-ssl || echo "NO")
role=$(/usr/share/google/get_metadata_value attributes/dataproc-role)
export FIRST_NAME_MASTER=$(/usr/share/google/get_metadata_value attributes/dataproc-master)
export OTHER_MASTERS=$(/usr/share/google/get_metadata_value attributes/dataproc-master-additional)
export NODE_NAME=$(/usr/share/google/get_metadata_value name)


export http_proxy="${METADATA_HTTP_PROXY}"
export https_proxy="${METADATA_HTTP_PROXY}"
export HTTP_PROXY="${METADATA_HTTP_PROXY}"
export HTTPS_PROXY="${METADATA_HTTP_PROXY}"
export no_proxy=169.254.169.254,metadata,metadata.google.internal
export NO_PROXY=169.254.169.254,metadata,metadata.google.internal

function install_storm_configuration() {
  # Find zookeeper list first, before attempting any installation.
  local zookeeper_client_port
  zookeeper_client_port=$(grep 'clientPort' /etc/zookeeper/conf/zoo.cfg |
    tail -n 1 |
    cut -d '=' -f 2)

  local zookeeper_list
  zookeeper_list=$(grep '^server\.' /etc/zookeeper/conf/zoo.cfg |
    cut -d '=' -f 2 |
    cut -d ':' -f 1 |
    sort |
    uniq |
    sed "s/$/:${zookeeper_client_port}/" |
    xargs echo |
    sed "s/ /,/g")

  local cluster_name
  cluster_name=$(/usr/share/google/get_metadata_value attributes/dataproc-cluster-name)

  local master_node
  master_node="$(/usr/share/google/get_metadata_value attributes/dataproc-master)"

  local master_node_yaml
  master_node_yaml="- ${master_node}"

  local additional_masters
  additional_masters=$(/usr/share/google/get_metadata_value attributes/dataproc-master-additional)

  local master_node_2=""
  local master_node_2_yaml=""
  if [ $additional_masters != "" ]; then
    master_node_2="$(echo $additional_masters | tr , ' ' | cut -f 1 -d ' ')"
    master_node_2_yaml="- ${master_node_2}"
  fi

  local master_node_3=""
  local master_node_3_yaml=""
  if [ $additional_masters != "" ]; then
    master_node_3="$(echo $additional_masters | tr , ' ' | cut -f 2 -d ' ')"
    master_node_3_yaml="- ${master_node_3}"
  fi

  cat <<EOF > /opt/apache-storm-${STORM_VERSION}/conf/storm.yaml
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

storm.zookeeper.servers:
     ${master_node_yaml}
     ${master_node_2_yaml}
     ${master_node_3_yaml}

nimbus.seeds: ["${master_node}"]
EOF
}

function install_fluentd_configuration() {
   # Case 40378239: the /etc/google-fluentd/config.d is not created if the cluster is created with the flag dataproc:dataproc.logging.stackdriver.enable=false
   # enable storm fluentd only if the directory exists
  if [[ -d /etc/google-fluentd/config.d ]]; then
  cat <<EOF > /etc/google-fluentd/config.d/storm_fluentd.conf
#################
#
# Apache Storm (init action)
#

# Fluentd config to tail the hadoop, hive, spark, zookeeper and hbase message log.
# Currently severity is a seperate field from the Cloud Logging log_level.
<source>
  @type tail
  format none
  path ${STORM_HOME}/logs/*,${STORM_HOME}/logs/*.log,${STORM_HOME}/logs/workers-artifacts/*/*/*.log
  pos_file /var/tmp/fluentd.dataproc.storm.pos
  refresh_interval 2s
  read_from_head true
  tag concat.raw.tail.*
</source>

<match concat.raw.tail.**>
  @type detect_exceptions
  remove_tag_prefix concat
  multiline_flush_interval 0.1
</match>

<filter raw.tail.**>
  @type parser
  key_name message
  <parse>
    @type multi_format
    <pattern>
      format /^((?<time>[^ ]* [^ ]*) *(?<severity>[^ ]*) *(?<class>[^ ]*): (?<message>.*))/
      time_format %Y-%m-%d %H:%M:%S,%L
    </pattern>
    <pattern>
      format /^((?<time>\S+)\s+(?<severity>\S+)\s+\[(?<thread>[^\]]*)\]\s+(?<class>\S+):\s+(?<message>.*))/
      time_format %Y-%m-%dT%H:%M:%S,%L
    </pattern>
    <pattern>
      format none
    </pattern>
  </parse>
</filter>

<match raw.tail.**>
  @type record_reformer
  renew_record false
  enable_ruby true
  auto_typecast true

  # "tag" is transtlated into log in Stackdriver
  # Strip the instance name and .log from the filename if present
  tag \${tag_suffix[-2].sub("-#{Socket.gethostname}", "").sub(/\.log\$/, "")}

  # The following can be used when turning on jobid re-logging:
  # dataproc.googleapis.com/process_id \${job}
  filename \${tag_suffix[-2]}
</match>
EOF

  systemctl reload google-fluentd 
  else
    echo "Skipped fluentd configuration for storm."
  fi   
}

function create_storm_user() {
  useradd -r -m -d ${STORM_USER_HOME} ${STORM_USER}
}


function download_and_unpack_storm() {
  echo "Downloading storm."
  curl -s -L -o - https://apache.osuosl.org/storm/apache-storm-${STORM_VERSION}/apache-storm-${STORM_VERSION}.tar.gz | tar -C /opt -xzf -
  chown -R ${STORM_USER} ${STORM_HOME}
}

function install_storm_ssl() {
  
  local storm_password_secret_name=$(/usr/share/google/get_metadata_value attributes/storm-password-secret-name)
  local storm_password_secret_version=$(/usr/share/google/get_metadata_value attributes/storm-password-secret-version || echo 1)
  local storm_password=$(gcloud secrets versions access --secret ${storm_password_secret_name} ${storm_password_secret_version} || echo storm-password)
  local bucket=$(/usr/share/google/get_metadata_value attributes/bucket-name)

  local ssl_key_path="${STORM_HOME}/security"
  local domain=$(hostname -d)
  local keystore_file="${ssl_key_path}/keystore.jks"
  local truststore_file="${ssl_key_path}/storm.truststore"
  local certificate_path="${ssl_key_path}/certificate.cert"
  
  mkdir -p $ssl_key_path

  if [ "${FIRST_NAME_MASTER}" == "${NODE_NAME}" ]; then

    echo "Generating keystore file."
    keytool -genkey -alias ssl_certificate_key -keyalg RSA -keystore ${keystore_file} \
    -noprompt -dname "CN=*.${domain}" -storepass "${storm_password}" -keypass "$storm_password"
    echo "Generating ssl certificate"
    keytool -export -alias ssl_certificate_key -file "${certificate_path}" -keystore ${keystore_file} -storepass "${storm_password}"
    echo "Attaching certificate to truststore"
    keytool -import -noprompt -alias ssl_certificate_key -file ${certificate_path} \
    -keystore ${truststore_file} -storepass "${storm_password}"

    echo "storing certificates and keystore in GCS"

    gsutil cp ${keystore_file}  gs://$bucket/certificates/
    gsutil cp ${truststore_file}  gs://$bucket/certificates/
    gsutil cp ${certificate_path}  gs://$bucket/certificates/

  else
    echo "Copying keystore, truststore and certificates to other nodes i.e secondary masters and workers"

    gsutil cp gs://$bucket/certificates/${keystore_file##*/} ${keystore_file}
    gsutil cp gs://$bucket/certificates/${truststore_file##*/} ${truststore_file}
    gsutil cp gs://$bucket/certificates/${certificate_path##*/} ${certificate_path}

  fi

  cat <<EOF >> /opt/apache-storm-${STORM_VERSION}/conf/storm.yaml

ui.https.keystore.type: "jks"
ui.https.port: 7443
ui.https.key.password: "$storm_password"
ui.https.keystore.password: "$storm_password"
ui.https.keystore.path: "$keystore_file"
ui.https.truststore.type: "jks"
ui.https.truststore.path: "$truststore_file"
ui.https.truststore.password: "$storm_password"

drpc.https.port: 8470
drpc.https.keystore.type: "jks"
drpc.https.keystore.path: "$keystore_file"
drpc.https.keystore.password: "$storm_password"
drpc.https.key.password: "$storm_password"
drpc.https.truststore.type: "jks"
drpc.https.truststore.path: "$truststore_file"
drpc.https.truststore.password: "$storm_password"

logviewer.https.port: 8000
logviewer.https.keystore.type: "jks"
logviewer.https.keystore.path: "$keystore_file"
logviewer.https.keystore.password: "$storm_password"
logviewer.https.key.password: "$storm_password"
logviewer.https.truststore.type: "jks"
logviewer.https.truststore.path: "$truststore_file"
logviewer.https.truststore.password: "$storm_password"
EOF

}

function install_nimbus_systemctl() {

  cat <<EOF > /usr/lib/systemd/system/nimbus.service
[Unit]
Description=Apache Storm Nimbus
After=network.target auditd.service

[Service]
User=${STORM_USER}
ExecStart=/opt/apache-storm-${STORM_VERSION}/bin/storm nimbus
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=on-failure
RestartPreventExitStatus=255
Type=simple
RuntimeDirectory=nimbus
RuntimeDirectoryMode=0755

[Install]
WantedBy=multi-user.target
Alias=nimbus.service
EOF

  # enable service so it restarts on reboot
  systemctl enable nimbus.service
  systemctl start nimbus.service
}

function install_supervisor_systemctl() {

  cat <<EOF > /usr/lib/systemd/system/storm-supervisor.service
[Unit]
Description=Apache Storm Supervisor
After=network.target auditd.service

[Service]
User=${STORM_USER}
ExecStart=/opt/apache-storm-${STORM_VERSION}/bin/storm supervisor
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=on-failure
RestartPreventExitStatus=255
Type=simple
RuntimeDirectory=storm-supervisor
RuntimeDirectoryMode=0755

[Install]
WantedBy=multi-user.target
Alias=storm-supervisor.service
EOF

  # enable service so it restarts on reboot
  systemctl enable storm-supervisor.service
  systemctl start storm-supervisor.service
}

function enable_storm_ui_systemctl() {

  cat <<EOF > /usr/lib/systemd/system/storm-ui.service
[Unit]
Description=Apache Storm UI
After=network.target auditd.service

[Service]
User=${STORM_USER}
ExecStart=/opt/apache-storm-${STORM_VERSION}/bin/storm ui
ExecReload=/bin/kill -HUP \$MAINPID
KillMode=process
Restart=on-failure
RestartPreventExitStatus=255
Type=simple
RuntimeDirectory=storm-ui
RuntimeDirectoryMode=0755

[Install]
WantedBy=multi-user.target
Alias=storm-ui.service
EOF

  # enable service so it restarts on reboot
  systemctl enable storm-ui.service
  systemctl start storm-ui.service
}



if [ "${FIRST_NAME_MASTER}" == "${NODE_NAME}" ]; then
  create_storm_user
  echo "${NODE_NAME} is the first master, installing nimbus."
  download_and_unpack_storm
  install_storm_configuration
  if [ ${STORM_ENABLE_SSL} == "YES" ]; then 
    install_storm_ssl      
  fi
  install_fluentd_configuration
  install_nimbus_systemctl
  enable_storm_ui_systemctl
fi

## install storm packages in secondary masters
if [ $OTHER_MASTERS != "" ]; then
  if grep -q "${NODE_NAME}" <<< "${OTHER_MASTERS}"; then
    create_storm_user
    echo "${NODE_NAME} is additional master, installing storm package."
    download_and_unpack_storm
    install_storm_configuration
    if [ ${STORM_ENABLE_SSL} == "YES" ]; then 
      install_storm_ssl      
    fi
    install_fluentd_configuration
  fi
fi

if [ ${role} == "Worker" ]; then
  create_storm_user
  echo "Install supervisor"
  download_and_unpack_storm
  install_storm_configuration
  if [ ${STORM_ENABLE_SSL} == "YES" ]; then 
    install_storm_ssl
  fi
  install_fluentd_configuration
  install_supervisor_systemctl
fi