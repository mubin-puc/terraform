#!/bin/bash

set -exo pipefail
export PATH=/usr/bin:$PATH
export METADATA_HTTP_PROXY=$(/usr/share/google/get_metadata_value attributes/http-proxy)
export http_proxy="${METADATA_HTTP_PROXY}"
export https_proxy="${METADATA_HTTP_PROXY}"
export HTTP_PROXY="${METADATA_HTTP_PROXY}"
export HTTPS_PROXY="${METADATA_HTTP_PROXY}"


/opt/conda/miniconda3/bin/pip install --upgrade spacy fuzzywuzzy strsimpy
/opt/conda/miniconda3/bin/spacy download en_core_web_lg
