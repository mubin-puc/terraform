#!/bin/bash

read -r -d '' var << EOM

hdfs soft core 409600
hdfs hard core 409600
hdfs soft memlock unlimited
hdfs hard memlock unlimited
hdfs soft nofile 32768
hdfs hard nofile 131072
hbase soft nofile 131072
hbase hard nofile 131072
hbase soft nproc 65536
hbase hard nproc 65536
mapred soft nproc 16384
mapred hard nproc 32768
mapred soft nofile 262144
mapred hard nofile 262144
gkafka soft nproc 16384
gkafka hard nproc 32768
gkafka soft nofile 262144
gkafka hard nofile 262144
hadoop10 soft nofile 32768
hadoop10 hard nofile 32768
hueadmin soft nofile 131072
hueadmin hard nofile 131072
hueadmin soft nproc 131072
hueadmin hard nproc 131072
dfsproxy soft nofile 131072
dfsproxy hard nofile 131072
ldap soft nproc 16384
ldap hard nproc 32768
ldap soft nofile 262144
ldap hard nofile 262144
* soft nofile 32768
* hard nofile 130000
* soft nproc 32768
* hard nproc 130000

EOM

echo "$var" > /etc/security/limits.conf
