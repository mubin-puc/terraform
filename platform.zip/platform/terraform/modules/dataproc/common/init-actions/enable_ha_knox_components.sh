#!bin/bash
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS-IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

set -x

readonly DEFAULT_TOPOLOGY_FILE="/etc/knox/conf/topologies/default.xml"
readonly TMP_TOPOLOGY_FILE="/tmp/ha.xml"
readonly PROTOCOL="http://"
readonly MASTER_1_HOSTNAME=$PROTOCOL`hostname`
readonly MASTER_2_HOSTNAME=$PROTOCOL`hostname | sed 's/.$/1/'`
readonly MASTER_3_HOSTNAME=$PROTOCOL`hostname | sed 's/.$/2/'`
readonly YARN_PORT="8088"
readonly HBASEUI_PORT="16010"
readonly SOLR_PORT="8983"
readonly WEBHCAT_PORT="50111"
readonly OOZIEUI_PORT="11000"
readonly OOZIE_PORT="11000"
readonly STORMUI_PORT="8080"
readonly DATAPROC_IMAGE=$(/usr/share/google/get_metadata_value image)
readonly XMLSTARLET_RPM_LOCATION=$(/usr/share/google/get_metadata_value attributes/xmlstartlet_rpm_location)

readonly HA_ALLOWED_COMPONENTS=(OOZIE OOZIEUI HBASEUI SOLR YARNUI RESOURCEMANAGER STORM)

function set_ha_provider_param_for_component() {
    xmlstarlet ed -L -s "/topology/gateway/provider[role='ha']" -t elem -n "param" \
-s "//param[last()]" -t elem -n "name" -v "$1" \
-s "//param[last()]" -t elem -n "value" -v "maxFailoverAttempts=3;failoverSleep=1000;enabled=true" $TMP_TOPOLOGY_FILE
}

function set_service_urls() { 
    if [ -n "$(xmlstarlet sel -T -t -v "/topology/service[role='$1']/url" $TMP_TOPOLOGY_FILE)" ]; then
        echo "Resource /topology/service[role='$1']/url already defined in $TMP_TOPOLOGY_FILE"
        xmlstarlet ed -L -d "/topology/service[role='$1']/url" $TMP_TOPOLOGY_FILE
        xmlstarlet ed -L -s "/topology/service[role='$1']" -t elem -n url -v $2 $TMP_TOPOLOGY_FILE
        xmlstarlet ed -L -s "/topology/service[role='$1']" -t elem -n url -v $3 $TMP_TOPOLOGY_FILE
        xmlstarlet ed -L -s "/topology/service[role='$1']" -t elem -n url -v $4 $TMP_TOPOLOGY_FILE
    else
    
       xmlstarlet ed -L -s "/topology" -t elem -n "service" -v ""  $TMP_TOPOLOGY_FILE
       xmlstarlet ed -L -s "/topology/service[not(role)]" -t elem -n role -v $1 $TMP_TOPOLOGY_FILE
       xmlstarlet ed -L -s "/topology/service[role='$1']" -t elem -n url -v $2 $TMP_TOPOLOGY_FILE
       xmlstarlet ed -L -s "/topology/service[role='$1']" -t elem -n url -v $3 $TMP_TOPOLOGY_FILE
       xmlstarlet ed -L -s "/topology/service[role='$1']" -t elem -n url -v $4 $TMP_TOPOLOGY_FILE
    fi
}

function get_urls_for_component() {
    case $1 in 
        "YARNUI") echo "$MASTER_1_HOSTNAME:$YARN_PORT \
                        $MASTER_2_HOSTNAME:$YARN_PORT \
                        $MASTER_3_HOSTNAME:$YARN_PORT";;
        "RESOURCEMANAGER") echo "$MASTER_1_HOSTNAME:$YARN_PORT/ws \
                                 $MASTER_2_HOSTNAME:$YARN_PORT/ws \
                                 $MASTER_3_HOSTNAME:$YARN_PORT/ws";;
        "HBASEUI") echo "$MASTER_1_HOSTNAME:$HBASEUI_PORT \
                            $MASTER_2_HOSTNAME:$HBASEUI_PORT \
                            $MASTER_3_HOSTNAME:$HBASEUI_PORT";;
        "SOLR") echo "$MASTER_1_HOSTNAME:$SOLR_PORT/solr \
                         $MASTER_2_HOSTNAME:$SOLR_PORT/solr \
                         $MASTER_3_HOSTNAME:$SOLR_PORT/solr";;
        "OOZIEUI") echo "$MASTER_1_HOSTNAME:$OOZIEUI_PORT/oozie/ \
                         $MASTER_2_HOSTNAME:$OOZIEUI_PORT/oozie/ \
                         $MASTER_3_HOSTNAME:$OOZIEUI_PORT/oozie/";;
        "OOZIE") echo "$MASTER_1_HOSTNAME:$OOZIE_PORT/oozie/ \
                       $MASTER_2_HOSTNAME:$OOZIE_PORT/oozie/ \
                       $MASTER_3_HOSTNAME:$OOZIE_PORT/oozie/";;
        "STORM") echo "$MASTER_1_HOSTNAME:$STORMUI_PORT \
                       $MASTER_2_HOSTNAME:$STORMUI_PORT \
                       $MASTER_3_HOSTNAME:$STORMUI_PORT";;
    esac
}

function rewrite_service_modules() {
    case $1 in
        "OOZIEUI")
            xmlstarlet ed -L -d "/rules/rule[@dir='OUT']" "/usr/lib/knox/data/services/oozieui/4.2.0/rewrite.xml"
            ;;
        "STORM")
            local base_service_path="/usr/lib/knox/data/services/storm/0.9.3/"
            local storm_rewrite_xml="$base_service_path/rewrite.xml"
            local storm_service_xml="$base_service_path/service.xml"
            local tmp_storm_rewrite_xml="/tmp/storm_rewrite.xml"
            local tmp_storm_service_xml="/tmp/storm_service.xml"
            if [ -e $base_service_path ]; then
                cat <<EOF > $tmp_storm_rewrite_xml
<!--
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
-->
<rules>
  <rule dir="IN" name="STORM/storm/inbound/request/root">
    <match pattern="*://*:*/**/storm?{**}">
      <rewrite template="{\$serviceUrl[STORM]}?{**}"/>
    </match>
  </rule>
  <rule dir="IN" name="STORM/storm/inbound/request/path">
    <match pattern="*://*:*/**/storm/{**}?{**}">
      <rewrite template="{\$serviceUrl[STORM]}/{**}?{**}"/>
    </match>
  </rule>
  <rule dir="IN" name="STORM/storm/inbound/api">
    <match pattern="*://*:*/**/api/v1/{**}">
      <rewrite template="{\$serviceUrl[STORM]}/api/v1/{**}"/>
    </match>
  </rule>
  <rule dir="IN" name="STORM/storm/api/topology">
    <match pattern="*://*:*/**/{**}?{**}">
      <rewrite template="{\$serviceUrl[STORM]}/{**}?{**}"/>
    </match>
  </rule>

  <!-- Resources -->
  <rule dir="IN" name="STORM/storm/inbound/styles" pattern="*://*:*/**/css/{**}">
    <rewrite template="{\$serviceUrl[STORM]}/css/{**}"/>
  </rule>

  <rule dir="IN" name="STORM/storm/inbound/scripts" pattern="*://*:*/**/js/{**}">
    <rewrite template="{\$serviceUrl[STORM]}/js/{**}"/>
  </rule>
  <rule dir="IN" name="STORM/storm/inbound/templates" pattern="*://*:*/**/templates/{**}?{**}">
    <rewrite template="{\$serviceUrl[STORM]}/templates/{**}?{**}"/>
  </rule>
  <rule dir="IN" name="STORM/storm/inbound/images" pattern="*://*:*/**/images/{**}">
    <rewrite template="{\$serviceUrl[STORM]}/images/{**}"/>
  </rule>
</rules>
EOF
                cat <<EOF > $tmp_storm_service_xml
<!--
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
-->
<service role="STORM" name="storm" version="0.9.3">
    <routes>
        <route path="/storm?**">
            <rewrite apply="STORM/storm/inbound/request/root" to="request.url"/>
            <rewrite apply="STORM/storm/outbound/response/path" to="response.body"/>
            <rewrite apply="STORM/storm/outbound/response/path" to="response.headers"/>
        </route>
        <route path="/storm/**?**">
            <rewrite apply="STORM/storm/inbound/request/path" to="request.url"/>
            <rewrite apply="STORM/storm/outbound/response/path" to="response.body"/>
            <rewrite apply="STORM/storm/outbound/response/path" to="response.headers"/>
        </route>
        <route path="/**?**">
            <rewrite apply="STORM/storm/api/topology" to="request.url"/>
        </route>
        <route path="/api/v1/**">
            <rewrite apply="STORM/storm/inbound/api" to="request.url"/>
        </route>
    <route path="/css/**">
        <rewrite apply="STORM/storm/inbound/styles" to="request.url"/>
    </route>

    <route path="/js/**">
        <rewrite apply="STORM/storm/inbound/scripts" to="request.url"/>
    </route>
    <route path="/images/**">
        <rewrite apply="STORM/storm/inbound/images" to="request.url"/>
    </route>
    <route path="/templates/**?**">
        <rewrite apply="STORM/storm/inbound/templates" to="request.url"/>
    </route>
    </routes>
    <dispatch classname="org.apache.knox.gateway.storm.StormDispatch"/>
    <testURLs>
        <testURL>/storm/api/v1/cluster/configuration</testURL>
        <testURL>/storm/api/v1/cluster/summary</testURL>
        <testURL>/storm/api/v1/supervisor/summary</testURL>
        <testURL>/storm/api/v1/topology/summary</testURL>
    </testURLs>
</service>
EOF
                cp $tmp_storm_rewrite_xml $storm_rewrite_xml
                cp $tmp_storm_service_xml $storm_service_xml
                # rm $tmp_storm_rewrite_xml $tmp_storm_service_xml
            else
              echo "Error: ${base_service_path} not found. Can not continue."
              exit 1
            fi
            ;;
        *)
        echo "Does not need rewriting of modules";;
    esac
}

function main() {
    if [[ "$DATAPROC_IMAGE" == *"roc"* ]]; then
        dnf -y -v install xmlstarlet
        if [ $? -ne 0 ]; then
          # unable to find xmlstarlet package
          # install lib xslt is a dependency
          dnf -y -v install libxslt
          if [ $? -ne 0 ]; then
            echo "Error installing libxslt. Exiting."
            exit 1
          fi

          RPM_NAME=`echo ${XMLSTARLET_RPM_LOCATION} | rev | cut -d "/" -f1 | rev`
          gsutil cp ${XMLSTARLET_RPM_LOCATION} /tmp/${RPM_NAME}
          if [ $? -ne 0 ]; then
            echo "Error copying xmlstarlet rpm. Exiting."
            exit 1
          fi

          rpm -Uvh /tmp/${RPM_NAME}
          if [ $? -ne 0 ]; then
            echo "Error installing xmlstarlet rpm. Exiting."
            exit 1
          fi
        fi
    else
        apt-get install -V -y xmlstarlet
    fi

    if [ -e "$DEFAULT_TOPOLOGY_FILE" ]; then
        cp $DEFAULT_TOPOLOGY_FILE $TMP_TOPOLOGY_FILE

        xmlstarlet ed -L -s "/topology/gateway" -t elem -n "provider" -s "//provider[last()]" -t elem -n "role" -v "ha" \
        -s "//provider[last()]" -t elem -n "name" -v "HaProvider" \
        -s "//provider[last()]" -t elem -n "enabled" -v "true"  $TMP_TOPOLOGY_FILE

        for component in ${HA_ALLOWED_COMPONENTS[@]}; do
            set_ha_provider_param_for_component $component
            set_service_urls $component $(get_urls_for_component $component)
            rewrite_service_modules $component
        done

        cp $TMP_TOPOLOGY_FILE $DEFAULT_TOPOLOGY_FILE
        rm $TMP_TOPOLOGY_FILE
    fi
}

main