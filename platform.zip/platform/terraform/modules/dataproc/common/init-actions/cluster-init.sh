#!bin/bash

export PATH=/usr/bin:$PATH
export METADATA_HTTP_PROXY=$(/usr/share/google/get_metadata_value attributes/http-proxy)
export http_proxy="${METADATA_HTTP_PROXY}"
export https_proxy="${METADATA_HTTP_PROXY}"
export HTTP_PROXY="${METADATA_HTTP_PROXY}"
export HTTPS_PROXY="${METADATA_HTTP_PROXY}"
export no_proxy=metadata.google.internal
export NO_PROXY=metadata.google.internal

function update_dpms() {

  sudo gsutil cp gs://metastore-init-actions/metastore-grpc-proxy/hms-proxy-3.1.2-v0.0.19.jar /usr/local/share/google/dataproc/dpms-proxy/3.1.2/hms-proxy-3.1.2.jar
  
  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/dpms-proxy/conf/proxy-config.xml' \
      --name 'proxy.max.message.size.bytes' --value "536870912" \
      --clobber

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/dpms-proxy/conf/proxy-config.xml' \
      --name 'grpc.max.retries' --value "5" \
      --clobber  
	  
  sudo systemctl restart dpms-proxy
}

function update_hive() {
	  
  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.support.concurrency' --value "false" \
      --clobber

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.fetch.task.conversion' --value "minimal" \
      --clobber

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.server.read.socket.timeout' --value "6000" \
      --clobber

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.server.tcp.keepalive' --value "true" \
      --clobber
	  
  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.metastore.client.socket.timeout' --value "1200" \
      --clobber	

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.metastore.batch.retrieve.max' --value "500" \
      --clobber	

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.metastore.batch.retrieve.table.partition.max' --value "1000" \
      --clobber	

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.metastore.server.min.threads' --value "500" \
      --clobber

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.msck.repair.batch.size' --value "2000" \
      --clobber
	  
  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.metastore.fshandler.threads' --value "200" \
      --clobber

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'orc.schema.evolution.case.sensitive' --value "false" \
      --clobber

  /usr/local/bin/bdconfig set_property \
      --configuration_file '/etc/hive/conf/hive-site.xml' \
      --name 'hive.msck.path.validation' --value "ignore" \
      --clobber

}

function main() {
  # Determine the role of this node
  local role
  role=$(/usr/share/google/get_metadata_value attributes/dataproc-role)

  # Only run on the master node of the cluster
  if [[ "${role}" == 'Master' ]]; then
    update_hive
    update_dpms
  fi
}

main