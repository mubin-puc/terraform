#!bin/bash

export PATH=/usr/bin:$PATH
export HIVE_CLIENT_DEP_GCS_LOCATION=$(/usr/share/google/get_metadata_value attributes/hive-client-dep-gcs-location)
export METADATA_HTTP_PROXY=$(/usr/share/google/get_metadata_value attributes/http-proxy)
export http_proxy="${METADATA_HTTP_PROXY}"
export https_proxy="${METADATA_HTTP_PROXY}"
export HTTP_PROXY="${METADATA_HTTP_PROXY}"
export HTTPS_PROXY="${METADATA_HTTP_PROXY}"
export no_proxy=metadata.google.internal
export NO_PROXY=metadata.google.internal

function install_hive_client_dependencies() {
    # copy hbase lib dependencies to the client cluster
	gsutil cp -R ${HIVE_CLIENT_DEP_GCS_LOCATION}/usr /
	
	# copy hbase configuration to the client cluster
	gsutil cp -R ${HIVE_CLIENT_DEP_GCS_LOCATION}/etc /
	
	# create synbolic links
	ln -s /etc/hbase/conf.dist /etc/hbase/conf
	ln -s /etc/hbase/conf /usr/lib/hbase/conf
}

function main() {
  # Determine the role of this node
  local role
  role=$(/usr/share/google/get_metadata_value attributes/dataproc-role)
  
  install_hive_client_dependencies
}

main
