import os
os.system("systemctl stop jupyter")
