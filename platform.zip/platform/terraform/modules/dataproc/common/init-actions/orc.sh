#!/bin/bash
# Copyright 2022 Google. This software is provided as-is, without warranty or representation for any use or purpose.
# Your use of it is subject to your agreement with Google.

set -euxo errexit

DEFAULT_ORC_VERSION="1.5.13"
ORC_VERSION="$(/usr/share/google/get_metadata_value attributes/orc-version || echo $DEFAULT_ORC_VERSION)"
PROXY="$(/usr/share/google/get_metadata_value attributes/http-proxy || echo '')"

if [ ! -z "${PROXY}" ];
then
  export HTTPS_PROXY=${PROXY}
  export http_proxy=${PROXY}
fi

# Remove the buggy version.
find /usr/lib -name 'orc-*-1.5.12.jar' -exec rm -f {} \;

curl -L https://repo1.maven.org/maven2/org/apache/orc/orc-core/${ORC_VERSION}/orc-core-${ORC_VERSION}.jar -o /usr/lib/hive/lib/orc-core-${ORC_VERSION}.jar
curl -L https://repo1.maven.org/maven2/org/apache/orc/orc-mapreduce/${ORC_VERSION}/orc-mapreduce-${ORC_VERSION}.jar -o /usr/lib/hive/lib/orc-mapreduce-${ORC_VERSION}.jar
curl -L https://repo1.maven.org/maven2/org/apache/orc/orc-shims/${ORC_VERSION}/orc-shims-${ORC_VERSION}.jar -o /usr/lib/hive/lib/orc-shims-${ORC_VERSION}.jar

cp /usr/lib/hive/lib/orc-core-${ORC_VERSION}.jar /usr/lib/spark/jars
cp /usr/lib/hive/lib/orc-mapreduce-${ORC_VERSION}.jar /usr/lib/spark/jars
cp /usr/lib/hive/lib/orc-shims-${ORC_VERSION}.jar /usr/lib/spark/jars