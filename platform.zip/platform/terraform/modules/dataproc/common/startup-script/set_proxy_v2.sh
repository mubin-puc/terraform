#!/bin/bash
# Copyright 2022 Google. This software is provided as-is, without warranty or representation for any use or purpose.
# Your use of it is subject to your agreement with Google.

set -ux
export DATAPROC_IMAGE=$(/usr/share/google/get_metadata_value image)
export PROXY="http://proxy.ebiz.verizon.com:9290"
#echo "proxy = http://proxy.ebiz.verizon.com:9290" >> /root/.curlrc;
#echo "noproxy = metadata.google.internal" >> /root/.curlrc;
echo http_proxy="${PROXY}" >> /etc/environment;
echo HTTP_PROXY="${PROXY}" >> /etc/environment;
echo https_proxy="${PROXY}" >> /etc/environment;
echo HTTPS_PROXY="${PROXY}" >> /etc/environment;
echo NO_PROXY="169.254.169.254,.internal,.verizon.com,.vzwcorp.com,.vzbi.com,.verizonwireless.com,.googleapis.com,.gcr.io,.gstatic.com,dl.google.com,packages.cloud.google.com" >> /etc/environment;
echo no_proxy="169.254.169.254,.internal,.verizon.com,.vzwcorp.com,.vzbi.com,.verizonwireless.com,.googleapis.com,.gcr.io,.gstatic.com,dl.google.com,packages.cloud.google.com" >> /etc/environment;

function update_knox() {
   echo "start fn update knox jars"
   sudo mv /usr/lib/knox/lib/gateway-server-1.3.0.jar /usr/lib/knox/lib/gateway-server-1.3.0.jar.bkp
   sudo gsutil cp gs://wdwg-dev-aidcom-0-usmr-initializationaction/initialization-actions/gateway-server-1.3.0.jar /usr/lib/knox/lib/
   sudo chmod 755 /usr/lib/knox/lib/gateway-server-1.3.0.jar 
  
   sudo mv /usr/lib/knox/lib/gateway-spi-1.3.0.jar /usr/lib/knox/lib/gateway-spi-1.3.0.jar.bkp
   sudo gsutil cp gs://wdwg-dev-aidcom-0-usmr-initializationaction/initialization-actions/gateway-spi-1.3.0.jar /usr/lib/knox/lib/
   sudo chmod 755 /usr/lib/knox/lib/gateway-spi-1.3.0.jar
}

function dataproc_maintenance_bypass() {
  echo "start fn maintenance bypass"	
  OS=$(grep '^ID=' /etc/os-release | cut -d= -f2)
  
  if [[ ${OS} == *rocky* ]]; then
    sudo sed -i "s/q \/tmp 1777 root root 10d/D \/tmp 1777 root root -/g" /usr/lib/tmpfiles.d/tmp.conf
    sudo sed -i "s/^q \/var\/tmp 1777 root root 30d/#q \/var\/tmp 1777 root root 30d/g" /usr/lib/tmpfiles.d/tmp.conf
    sudo systemctl restart systemd-tmpfiles-clean.timer
    sudo systemctl daemon-reload
  fi
}

function main() {
  #Determine the role of this node
  local role
  role=$(/usr/share/google/get_metadata_value attributes/dataproc-role)
  #Only run on the master nodes of the cluster
  if [[ "${role}" == 'Master' ]]; then
	dataproc_maintenance_bypass
	update_knox
  fi
}

main